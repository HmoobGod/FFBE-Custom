# Review scope and limitations

1. managementAction: first statement denies before busy flag or scheduling. openSaveTransfer delegates to it.
2. perform: first statement denies before SaveSlots.activity or any save dispatch. Existing worker catches the exception, emits a message and clears busy; JSON argument parsing can precede perform but does not access saves.
3. onCreate: immediately after required super call, before fresh/restored branch.
4. onActivityResult: immediately after super, before request routing, URI inspection or scheduling.
5. Import worker: first statement inside existing try, before ensureStage or file/URI access; existing catch/finally may report denial and clear busy/finish, without accessing saves.

The shared gate unconditionally throws. These exact insertions leave all original statements intact and retain the entire six-file parent source. No claim about superclass effects, Activity instantiation, native/JNI entry points, other direct package-private helpers (including prepare/install/recover), platform reachability, process isolation, race-free access, or crash durability. Nothing authorizes gameplay. The parent logs are embedded historical evidence and not rerun.
