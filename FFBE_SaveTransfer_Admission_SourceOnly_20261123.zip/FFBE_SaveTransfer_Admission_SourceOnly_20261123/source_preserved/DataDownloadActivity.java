package com.exvius.local;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** First-install data download; subsequent launches go straight to the game. */
public final class DataDownloadActivity extends Activity implements DataUpdates.Progress {
    private TextView status;
    private ProgressBar progress;
    private Button retry;
    private boolean repairAssets;
    private volatile int displayAttempt;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        DataUpdates.initialize(getApplicationContext());
        if (DataUpdates.ready(this)) {
            openGame(true);
            return;
        }
        if (DataUpdates.hasPending(this) && DataUpdates.gameOpened()) {
            showDownloadPage();
            failed("An update is ready. Fully close Exvius, then open it again to apply the update.");
            return;
        }
        repairAssets = DataUpdates.clientAssetsMissing(this);
        showDownloadPage();
        DataUpdates.prepare(this, this, repairAssets);
    }

    private void showDownloadPage() {
        if (status != null) return;
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        int padding = (int) (24 * getResources().getDisplayMetrics().density);
        page.setPadding(padding, padding, padding, padding);
        TextView title = new TextView(this);
        title.setText("Exvius Offline");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        page.addView(title);
        status = new TextView(this);
        status.setText("Preparing the complete game data download.\nAfter setup, you can play offline.");
        status.setTextSize(17);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, padding, 0, padding);
        page.addView(status);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        page.addView(progress, new LinearLayout.LayoutParams(-1, -2));
        retry = new Button(this);
        retry.setText("Retry");
        retry.setVisibility(View.GONE);
        retry.setOnClickListener(view -> {
            displayAttempt++;
            retry.setVisibility(View.GONE);
            status.setText("Checking for game data...");
            DataUpdates.retry(this, this, repairAssets);
        });
        page.addView(retry);
        setContentView(page);
    }

    private void openGame(boolean checkForUpdates) {
        // Completed mandatory setup remains visible, but never admits gameplay.
        if (!BootstrapAdmissionGate.gameplayApproved()) {
            showDownloadPage();
            status.setText("Game data setup complete. Gameplay remains on HOLD.");
            retry.setVisibility(View.GONE);
            return;
        }
        try {
            GameAssets.attach(getApplicationContext());
        } catch (IllegalStateException error) {
            android.util.Log.e("ExviusUpdates", "Could not open downloaded client assets", error);
            repairAssets = true;
            showDownloadPage();
            failed("The game assets could not be opened. Connect to the internet and tap Retry to repair them.");
            return;
        }
        Intent game = new Intent();
        game.setClassName(getPackageName(), "com.square_enix.android_googleplay.FFBEWW.Lapis");
        startActivity(game);
        finish();
    }
    @Override public void onDestroy() {
        DataUpdates.detach(this);
        super.onDestroy();
    }
    @Override public void onResume() {
        super.onResume();
        DataUpdates.installerReturned();
    }

    @Override public void update(String message, long done, long total, boolean retryAvailable) {
        int attempt = displayAttempt;
        runOnUiThread(() -> {
            if (isFinishing() || attempt != displayAttempt) return;
            status.setText(message);
            retry.setVisibility(retryAvailable ? View.VISIBLE : View.GONE);
            progress.setIndeterminate(total <= 0);
            if (total > 0) progress.setProgress((int) Math.min(1000, done * 1000 / total));
        });
    }
    @Override public void complete() {
        int attempt = displayAttempt;
        runOnUiThread(() -> { if (!isFinishing() && attempt == displayAttempt) openGame(false); });
    }
    @Override public void failed(String message) {
        int attempt = displayAttempt;
        runOnUiThread(() -> {
            if (isFinishing() || attempt != displayAttempt) return;
            status.setText(message);
            progress.setIndeterminate(false);
            retry.setVisibility(View.VISIBLE);
        });
    }
}
