package com.exvius.local;

import android.content.Context;
import java.io.File;
import java.io.IOException;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;

/**
 * DISPOSABLE SOURCE-ONLY DESIGN, NOT FOR APPLICATION USE.
 *
 * A conservative metadata-only pre-check before SaveSlots.initialize().
 * It NEVER authorizes runtime startup: Java cannot yet attest the earlier Android
 * provider chain, Python argv/sys.modules, update workers or write confinement.
 * No directory creation, file content reading, save recovery or network access.
 */
final class BootstrapAdmissionGate {
    private static final String UNVERIFIED =
        "FFBE SOURCE-ONLY HOLD: process argv, Python preloads, earlier providers, " +
        "save/write isolation and background updates are not independently verified";

    private BootstrapAdmissionGate() {}

    static void requireBeforeSaveSlots(Context context) {
        if (context == null) throw new IllegalStateException("FFBE HOLD: missing Android context");
        try {
            File files = context.getFilesDir();
            File trusted = trustedFilesDirectory(files);
            File writable = new File(files, "exvius");
            File state = new File(writable, "state");
            File slots = new File(state, "slots");
            File install = new File(writable, "data");
            File staticRoot = new File(install, "static");
            File nativeRoot = files;

            // Require the intended paths to exist and to contain NO symlink segments.
            requireDirectory(trusted, writable);
            requireDirectory(trusted, state);
            requireDirectory(trusted, slots);
            requireDirectory(trusted, install);
            requireDirectory(trusted, staticRoot);
            requireDirectory(trusted, new File(nativeRoot, "mst"));
            requireDirectory(trusted, new File(nativeRoot, "common_lang"));

            // Existing valid data is a requirement; never create a catalogue here.
            // Full contents/slot-ID validation is NOT proven by this metadata check.
            requireRegularFile(trusted, new File(slots, "index.json"));
            requireRegularFile(trusted, new File(install, "installed.json"));

            // Any pending transaction must be resolved outside the trial, never here.
            requireAbsent(trusted, new File(slots, "delete.json"));
            requireAbsent(trusted, new File(new File(slots, "import"), "journal.json"));
            requireAbsent(trusted, new File(install, "pending.json"));
            requireAbsent(trusted, new File(install, "install-progress.json"));
        } catch (IOException | SecurityException error) {
            throw new IllegalStateException("FFBE HOLD: untrusted or uninspectable game roots", error);
        }

        // Intentionally UNCONDITIONAL. These hazards cannot be cleared by this
        // provider-level source check or by the synthetic Python preflight.
        throw new IllegalStateException(UNVERIFIED);
    }

    // Android API 21+ lstat never follows the last segment: a dangling symlink
    // is PRESENT and unsafe, not an absent file. Every returned errno other than
    // ENOENT is a hard HOLD. This does not make path checks race-free.
    private static StructStat inspectExisting(File path) throws IOException {
        try {
            StructStat info = Os.lstat(path.getPath());
            if (OsConstants.S_ISLNK(info.st_mode)) {
                throw new IOException("symbolic link in application data path");
            }
            return info;
        } catch (ErrnoException failure) {
            throw new IOException("cannot inspect application data path", failure);
        }
    }

    private static File trustedFilesDirectory(File files) throws IOException {
        if (files == null) throw new IOException("missing files directory");
        File absolute = files.getAbsoluteFile();
        if (!absolute.equals(files.getCanonicalFile()) ||
            !OsConstants.S_ISDIR(inspectExisting(absolute).st_mode)) {
            throw new IOException("files directory is not trusted");
        }
        return absolute;
    }

    private static File trustedPath(File filesRoot, File candidate) throws IOException {
        File absolute = candidate.getAbsoluteFile();
        String prefix = filesRoot.getPath() + File.separator;
        if (!absolute.getPath().startsWith(prefix) ||
            !absolute.equals(candidate.getCanonicalFile())) {
            throw new IOException("noncanonical or escaping application data path");
        }
        return absolute;
    }

    private static String[] relativeParts(File root, File child) throws IOException {
        File trusted = trustedPath(root, child);
        String relative = trusted.getPath().substring(root.getPath().length() + 1);
        if (relative.isEmpty()) throw new IOException("missing relative path");
        String[] parts = relative.split(java.util.regex.Pattern.quote(File.separator), -1);
        for (String part : parts) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) {
                throw new IOException("invalid path segment");
            }
        }
        return parts;
    }

    private static void requireExistingKind(File root, File target, boolean directory)
            throws IOException {
        String[] parts = relativeParts(root, target);
        File current = root;
        for (int i = 0; i < parts.length; i++) {
            current = new File(current, parts[i]);
            StructStat stat = inspectExisting(current);
            boolean wantDirectory = directory || i < parts.length - 1;
            if (wantDirectory ? !OsConstants.S_ISDIR(stat.st_mode) :
                                !OsConstants.S_ISREG(stat.st_mode)) {
                throw new IOException("required path has incorrect file type");
            }
        }
    }

    private static void requireDirectory(File filesRoot, File value) throws IOException {
        requireExistingKind(filesRoot, value, true);
    }

    private static void requireRegularFile(File filesRoot, File value) throws IOException {
        requireExistingKind(filesRoot, value, false);
    }

    private static void requireAbsent(File filesRoot, File value) throws IOException {
        String[] parts = relativeParts(filesRoot, value);
        File current = filesRoot;
        for (int i = 0; i < parts.length; i++) {
            // Each ancestor was successfully lstat'd as a real directory.
            // ENOENT alone means this next component is absent. EACCES,
            // ENOTDIR, ELOOP, EIO and every other errno remain HOLD.
            current = new File(current, parts[i]);
            final StructStat stat;
            try {
                stat = Os.lstat(current.getPath());
            } catch (ErrnoException failure) {
                if (failure.errno == OsConstants.ENOENT) return;
                throw new IOException("pending marker existence cannot be determined", failure);
            }
            if (OsConstants.S_ISLNK(stat.st_mode)) {
                throw new IOException("symbolic link at pending marker path");
            }
            if (i == parts.length - 1) {
                throw new IOException("unresolved game or save transaction present");
            }
            if (!OsConstants.S_ISDIR(stat.st_mode)) {
                throw new IOException("pending marker ancestor is not a directory");
            }
        }
        throw new IOException("indeterminate pending marker state");
    }

    /** Stage 1: metadata-only precondition. Not authorization to start FFBE. */
    static void requireInstallationOnly(Context context) {
        if (context == null) throw new IllegalStateException("FFBE HOLD: missing Android context");
        try {
            trustedFilesDirectory(context.getFilesDir());
        } catch (IOException | SecurityException error) {
            throw new IllegalStateException("FFBE HOLD: untrusted installation root", error);
        }
        // No SaveSlots, LocalGameBridge, DataUpdates or Python initialization here.
    }

    /** Metadata-only precondition for the shared resource registry; never recover saves. */
    static void requireSharedGamedataWriteAdmission(Context context) throws IOException {
        try {
            if (context == null || context.getApplicationInfo() == null ||
                context.getApplicationInfo().dataDir == null) {
                throw new IOException("missing application data root");
            }
            File dataRoot = trustedFilesDirectory(new File(context.getApplicationInfo().dataDir));
            File filesRoot = trustedFilesDirectory(context.getFilesDir());
            if (!filesRoot.equals(new File(dataRoot, "files"))) {
                throw new IOException("unexpected application files root");
            }
            // A missing ancestor is allowed only after lstat confirms ENOENT.
            // Journal siblings may be left by an interrupted AtomicFile write.
            String[] suffixes = {"", ".bak", ".new", ".tmp"};
            for (String suffix : suffixes) {
                requireAbsent(filesRoot, new File(filesRoot, "exvius/state/slots/delete.json" + suffix));
                requireAbsent(filesRoot, new File(filesRoot, "exvius/state/slots/import/journal.json" + suffix));
                requireAbsent(filesRoot, new File(filesRoot, "exvius/state/slots/import/import.zip" + suffix));
                if (!suffix.isEmpty()) {
                    requireAbsent(filesRoot, new File(filesRoot, "exvius/state/slots/index.json" + suffix));
                    requireAbsent(dataRoot, new File(dataRoot, "shared_prefs/gamedata.xml" + suffix));
                }
            }
            requireAbsent(filesRoot, new File(filesRoot, "exvius/state/slots/import/prepared"));
            requireOptionalRegularFile(filesRoot, new File(filesRoot, "exvius/state/slots/index.json"));
            requireOptionalRegularFile(dataRoot, new File(dataRoot, "shared_prefs/gamedata.xml"));
        } catch (IOException | SecurityException error) {
            throw new IOException("FFBE HOLD: shared resource registry write is not admitted; save transaction or unsafe metadata", error);
        }
        // This is a metadata snapshot, not a lock or crash-durability guarantee.
    }

    private static void requireOptionalRegularFile(File root, File value) throws IOException {
        String[] parts = relativeParts(root, value);
        File current = root;
        for (int i = 0; i < parts.length; i++) {
            current = new File(current, parts[i]);
            final StructStat stat;
            try {
                stat = Os.lstat(current.getPath());
            } catch (ErrnoException failure) {
                if (failure.errno == OsConstants.ENOENT) return;
                throw new IOException("shared preference path cannot be inspected", failure);
            }
            if (OsConstants.S_ISLNK(stat.st_mode) ||
                (i < parts.length - 1 ? !OsConstants.S_ISDIR(stat.st_mode) :
                                        !OsConstants.S_ISREG(stat.st_mode))) {
                throw new IOException("shared preference path has unsafe file type");
            }
        }
    }

    /** Stage 2 is permanently disabled in this disposable design. */
    static boolean gameplayApproved() {
        return false;
    }

    /** For every known local-server path, deny before any effect or cached game. */
    static void requireGameplayAdmission() {
        throw new IllegalStateException(UNVERIFIED);
    }
}
