"""Static exact-source checks and fake-only routes. No Java or FFBE execution."""
import hashlib, pathlib, re, unittest, zipfile, io
ROOT=pathlib.Path(__file__).resolve().parents[1]
ORIG=(ROOT/'source_original/SaveTransferActivity.java').read_bytes()
NEW=(ROOT/'source_disposable/SaveTransferActivity.java').read_bytes()
G=b'BootstrapAdmissionGate.requireGameplayAdmission();'
ANCHORS=[(b'    public static boolean managementAction(String action, String argument) {\r\n',8), (b'    private static void perform(String action, JSONObject row) throws Exception {\r\n',8), (b'        super.onCreate(state);\r\n',8), (b'        super.onActivityResult(request, result, data);\r\n',8), (b'        worker.execute(() -> {\r\n            try {\r\n',16)]
PARENT=ROOT/'input/FFBE_SaveRestart_Admission_SourceOnly_20261123.zip'

def validate(s):
    # All anchors unique, all guards immediate, and every other byte unchanged.
    assert s.count(G)==5
    for a,i in ANCHORS:
        assert s.count(a+b' '*i+G+b'\r\n')==1
    assert re.sub(rb'(?m)^ +BootstrapAdmissionGate\.requireGameplayAdmission\(\);\r\n',b'',s)==ORIG
    assert s.count(b'\r\n')==ORIG.count(b'\r\n')+5

class Checks(unittest.TestCase):
    def test_exact_source(self):
        self.assertEqual(len(ORIG),32219)
        self.assertEqual(hashlib.sha1(b'blob '+str(len(ORIG)).encode()+b'\0'+ORIG).hexdigest(),'02b407775c0a59699f3a593fe34843a9a15aee23')
    def test_exact_diff(self): validate(NEW)
    def test_parent_hash(self): self.assertEqual(hashlib.sha256(PARENT.read_bytes()).hexdigest(),'b7f0ad795aba5ab6b9dd6f74f16235015c97e7b1c9b2399d4302f1f7134f6dff')
    def test_preserved_sources(self):
        with zipfile.ZipFile(PARENT) as z:
            paths=[n for n in z.namelist() if '/source_preserved/' in n or n.endswith('/source_disposable/SaveRestartActivity.java')]
            self.assertEqual(len(paths),6)
            for n in paths: self.assertEqual(z.read(n),(ROOT/'source_preserved'/pathlib.PurePosixPath(n).name).read_bytes())
    def test_gate_unconditional(self):
        s=(ROOT/'source_preserved/BootstrapAdmissionGate.java').read_bytes()
        self.assertIn(b'static void requireGameplayAdmission() {\n        throw new IllegalStateException(UNVERIFIED);\n    }',s)
        self.assertIn(b'static boolean gameplayApproved() {\n        return false;',s)
    def test_bridge_restart(self):
        for n,count in [('LocalGameBridge.java',26),('SaveRestartActivity.java',4)]:self.assertEqual((ROOT/'source_preserved'/n).read_bytes().count(G),count)
    def test_installer_and_registry(self):
        s=(ROOT/'source_preserved/DataUpdates.java').read_bytes()
        for token in [b'AUTOMATIC_APP_INSTALLER_APPROVED = false;',b'if (AUTOMATIC_APP_INSTALLER_APPROVED) maybeInstall(activity);',b'if (AUTOMATIC_APP_INSTALLER_APPROVED && activity != null)',b'if (!AUTOMATIC_APP_INSTALLER_APPROVED) return;',b'BootstrapAdmissionGate.requireSharedGamedataWriteAdmission(context);']:self.assertIn(token,s)
    def test_import_guard_before_try_effects(self):
        self.assertIn(ANCHORS[-1][0]+b' '*16+G+b'\r\n                ensureStage(this);',NEW)
    def test_worker_dispatch(self):
        self.assertIn(b'try { perform(action, new JSONObject(argument)); }',NEW)
        self.assertIn(ANCHORS[1][0]+b' '*8+G+b'\r\n        Activity a = SaveSlots.activity();',NEW)
    def test_open_delegates(self): self.assertIn(b'openSaveTransfer() { return managementAction("open", "{}"); }',NEW)
    def test_callbacks(self):
        self.assertIn(ANCHORS[2][0]+b' '*8+G+b'\r\n        if (state == null)',NEW)
        self.assertIn(ANCHORS[3][0]+b' '*8+G+b'\r\n        if (request != PICK_IMPORT)',NEW)

# Mutation cases remove, weaken or move each specific guard, not just count it.
for idx,(a,i) in enumerate(ANCHORS):
    target=a+b' '*i+G+b'\r\n'
    def test(self,a=a,i=i,target=target):
        with self.assertRaises(AssertionError):validate(NEW.replace(target,a,1))
    setattr(Checks,f'test_mutation_remove_{idx}',test)
    def test(self,a=a,i=i,target=target):
        with self.assertRaises(AssertionError):validate(NEW.replace(target,a+b' '*i+b'if (false) '+G+b'\r\n',1))
    setattr(Checks,f'test_mutation_weaken_{idx}',test)
    def test(self,a=a,i=i,target=target):
        with self.assertRaises(AssertionError):validate(NEW.replace(target,a+b' '*i+b'// guard displaced\r\n'+b' '*i+G+b'\r\n',1))
    setattr(Checks,f'test_mutation_displace_{idx}',test)

# Fake route model derives entry denial from each exact source anchor and gate contract.
# No Android callbacks, archives, save files, or native operations are executed.
ROUTES={'open':0,'export':0,'rename':0,'delete':0,'import':0,'cancel':0,'queued_management':1,'new_activity':2,'restored_activity':2,'cancelled_result':3,'unrelated_result':3,'valid_result':3,'queued_import':4}
for name,idx in ROUTES.items():
    def test(self,idx=idx):
        a,i=ANCHORS[idx]; seen=[]
        def fake_call():
            if a+b' '*i+G+b'\r\n' in NEW: raise RuntimeError('HOLD')
            seen.append('protected effect')
        with self.assertRaisesRegex(RuntimeError,'HOLD'):fake_call()
        self.assertEqual(seen,[])
    setattr(Checks,'test_route_'+name,test)
